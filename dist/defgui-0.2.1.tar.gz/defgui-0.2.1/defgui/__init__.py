from defgui.streamlit import defgui_streamlit
from defgui.tkinter import defgui_tkinter